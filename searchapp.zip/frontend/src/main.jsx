import React from 'react';
import ReactDOM from 'react-dom/client';
import PartSearchApp from './PartSearchApp';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <PartSearchApp />
  </React.StrictMode>
);
